import art
import banner
import terminal_banner
import requests

#banner+art
def get_banners():
    for font in art.FONT_NAMES:
        yield art.text2art("python", font)
choice = banner.choose(*get_banners())
print(choice)

#terminal_banner
kata_kata = "~~SubDoScan~~\n\nPowered by n00bX8"
logo_ku = terminal_banner.Banner(kata_kata)
print(logo_ku)

#input link web
web = input("Masukkan Link,, contoh github.com: ")

#menggunakan api hackertarget
n00bX8 = requests.get("http://api.hackertarget.com/hostsearch/?q=" + web)

#hasilnya
print(n00bX8.text)
